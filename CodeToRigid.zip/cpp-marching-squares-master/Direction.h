/**
 * A direction in the plane. As a convenience, directions provide unit vector
 * components (manhattan metric) for both the conventional plane and screen
 * coordinates (y axis reversed).
 *
 * @author Tom Gibara
 * Ported to C++ by Juha Reunanen
 *
 */

#pragma once

#include <utility>
#include <box2d/math_functions.h>

namespace MarchingSquares {
	// NOTE: "inline" was previously (incorrectly) placed on the struct
	// definition itself ("inline struct Direction {...}"), which is a
	// no-op for a type (MSVC even warns C4091 about it) and did nothing
	// to prevent ODR violations. The actual problem is every FUNCTION
	// below having a body directly in this header with external linkage:
	// any .cpp that includes Direction.h gets its own full definition of
	// each one, and the linker collides the moment more than one .cpp
	// does (LNK2005 "already defined"). Marking each function inline is
	// what actually fixes that — it tells the linker these are the same
	// definition wherever they appear and to fold them into one.
	struct Direction {
		Direction() : x(0), y(0) {}
		Direction(int x, int y) : x(x), y(y) {}
		Direction(b2Vec2 vec) : x(vec.x), y(vec.y) {}
		int x;
		int y;
	};

	inline bool operator==(const Direction& a, const Direction& b) {
		return a.x == b.x && a.y == b.y;
	}

	inline Direction operator*(const Direction& direction, int multiplier) {
		return Direction(direction.x * multiplier, direction.y * multiplier);
	}

	inline Direction operator+(const Direction& a, const Direction& b) {
		return Direction(a.x + b.x, a.y + b.y);
	}

	inline Direction& operator+=(Direction& a, const Direction& b) {
		a.x += b.x;
		a.y += b.y;
		return a;
	}

	inline Direction MakeDirection(int x, int y) { return Direction(x, y); }

	inline Direction East() { return MakeDirection(1, 0); }
	inline Direction Northeast() { return MakeDirection(1, 1); }
	inline Direction North() { return MakeDirection(0, 1); }
	inline Direction Northwest() { return MakeDirection(-1, 1); }
	inline Direction West() { return MakeDirection(-1, 0); }
	inline Direction Southwest() { return MakeDirection(-1, -1); }
	inline Direction South() { return MakeDirection(0, -1); }
	inline Direction Southeast() { return MakeDirection(1, -1); }
}